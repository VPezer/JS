function zadatak1() {
    let prednosti = document.getElementById("prednosti")
    prednosti.style.backgroundColor = "yellow"
}

function zadatak2() {
    let odjeljci = document.getElementsByClassName("odjeljak")
    for (let i = 0; i < odjeljci.length; i++) {
        odjeljci[i].style.fontSize = "16px"
    }
}

function zadatak3() {
    let prednosti = document.getElementById("prednosti")
    prednosti.innerHTML = "<h2>Prednosti</h2><p>Ova sekcija je promijenjena korištenjem DOM-a</p>"
}

function zadatak4() {
    let sekcije = document.getElementsByTagName("section")
    for (let i = 0; i < sekcije.length; i++) {
        sekcije[i].style.backgroundColor = "lightblue"
    }
}

let pozadinaBijela = true

function zadatak5() {
    if (pozadinaBijela) {
        document.body.style.backgroundColor = "lightgreen"
        pozadinaBijela = false
    } else {
        document.body.style.backgroundColor = "white"
        pozadinaBijela = true
    }
}

function zadatak6() {
    let paragraf = document.getElementById("prikaz-tekst-par")
    paragraf.style.display = "block"
    paragraf.textContent = "Ovo je tekst koji se prikazuje klikom na gumb!"
}

let prikazanaPrva = true

function zadatak7() {
    let slika = document.getElementById("mojaSLika")
    if (prikazanaPrva) {
        slika.setAttribute("src", "https://picsum.photos/seed/technology/300/200")
        prikazanaPrva = false
    } else {
        slika.setAttribute("src", "https://picsum.photos/seed/ai-robot/300/200")
        prikazanaPrva = true
    }
}

function dodajParagraf() {
    let noviParagraf = document.createElement("p")             // korak 1
    let tekst = document.createTextNode("Ovo je novi paragraf") // korak 2
    noviParagraf.appendChild(tekst)                             // korak 3
    let kontejner = document.getElementById("paragrafi")
    kontejner.appendChild(noviParagraf)                         // korak 4
}
